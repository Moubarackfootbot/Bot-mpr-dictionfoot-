import streamlit as st

# Configuration de la page
st.set_page_config(page_title="Prédictions Foot - Bot FR", layout="centered")
st.title("⚽ Bot de Prédiction de Match (FR)")
st.write("Pose une question sur un match de football (en français uniquement).")

# Entrée utilisateur
question = st.text_input("Ta question :", placeholder="Ex : Qui va gagner entre le PSG et l'OM ?")

# Fonction de prédiction simple
def predire_resultat(question):
    question_lower = question.lower()
    if not any(char in question_lower for char in "éèàçùôî"):
        return "Je ne réponds qu'en français, s'il vous plaît."

    if "psg" in question_lower and "marseille" in question_lower:
        return "Le PSG a gagné 4 des 5 derniers matchs contre l'OM. Avantage PSG !"
    elif "real madrid" in question_lower:
        return "Le Real Madrid est en grande forme. Ils sont favoris."
    elif "barcelone" in question_lower:
        return "Le Barça a connu des hauts et des bas, match équilibré en vue."
    else:
        return "Désolé, je n'ai pas assez d'informations pour ce match. Essaie une autre question."

# Afficher la réponse
if question:
    reponse = predire_resultat(question)
    st.success(reponse)
