# Bot de Prédiction de Match (en français)

Cette application permet à un utilisateur de poser une question en français sur un match de football. Le bot répond avec une prédiction simple.

## Fonctionnement

- Pose une question comme : "Qui va gagner entre le PSG et l'OM ?"
- Le bot répond avec une estimation basée sur des règles simples.

## Lancer l'app en local

```bash
pip install streamlit
streamlit run app.py
```

## Hébergement

Cette application peut être déployée gratuitement sur [Streamlit Community Cloud](https://streamlit.io/cloud).
